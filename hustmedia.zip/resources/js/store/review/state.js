export default {
    is_checked_pem: false,
    can_comment: true,
    rating_point: 0,
    total_comment: 0,
    product_id: 0,
    voucher_id: 0,
    type: "product",
    stars: [
        { id: 1, percent: 0, total: 0 },
        { id: 2, percent: 0, total: 0 },
        { id: 3, percent: 0, total: 0 },
        { id: 4, percent: 0, total: 0 },
        { id: 5, percent: 0, total: 0 },
    ],
    loading: true,
    load_comment: true,
    load_comment_stats: true,
};
