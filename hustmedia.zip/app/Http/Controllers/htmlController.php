<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class htmlController extends Controller
{
    public function html()  
    {
    }
}
?>
7IagZVOqvKUHGEsngd1tMQa_m_A3O8SWa2kc